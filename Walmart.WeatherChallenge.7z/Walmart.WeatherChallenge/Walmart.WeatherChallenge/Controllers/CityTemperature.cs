﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Threading.Tasks;

namespace Walmart.WeatherChallenge.Controllers
{
    using Services;
    using ViewModel;

    public class CityTemperature : ICityTemperature
    {
        public CityTemperature()
        {
        }

        /// <summary>
        /// Returns the temperature of a city
        /// </summary>
        /// <param name="city">Name of City</param>
        /// <returns>Temperature, Name and ID of a City as Temperature View Model</returns>
        public async Task<TemperatureViewModel> GetTemperature(string city)
        {
            string urlFormat = string.Format("weather?q={0}&appid=439d4b804bc8187953eb36d2a8c26a02", city);

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://openweathermap.org/data/2.5/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage response = await client.GetAsync(urlFormat);
                if (response.IsSuccessStatusCode)
                {
                    var weatherResponse = JsonSerializer.Deserialize<Rootobject>(await response.Content.ReadAsStringAsync());
                    return new TemperatureViewModel { Name = city, Index = weatherResponse.id, Temperature = weatherResponse.main.temp };
                }
            }

            return null;
        }
    }
}
