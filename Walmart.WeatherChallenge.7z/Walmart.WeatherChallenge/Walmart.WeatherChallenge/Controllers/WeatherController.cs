﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace Walmart.WeatherChallenge.Controllers
{
    using Services;
    using ViewModel;

    [ApiController]
    [Route("[controller]")]

    public class WeatherController : ControllerBase
    {
        private readonly ICityTemperature cityTemperature;

        public WeatherController(ICityTemperature cityTemperature)
        {
            this.cityTemperature = cityTemperature;
        }

        //Sample Request : /weather?cities=Bangalore,London
        
        [HttpGet]
        public ActionResult<List<TemperatureViewModel>> Get(string cities)
        {
            var response = new List<TemperatureViewModel>();

            if (!string.IsNullOrWhiteSpace(cities))
            {
                string[] citiesList = cities.Split(',');

                foreach (var city in citiesList)
                {
                    var cityRespone = cityTemperature.GetTemperature(city).Result;

                    if (cityRespone != null)
                        response.Add(cityRespone);
                }

                return response.OrderByDescending(x => x.Temperature).ToList();
            }
            return NotFound();

            
        }
    }
}
