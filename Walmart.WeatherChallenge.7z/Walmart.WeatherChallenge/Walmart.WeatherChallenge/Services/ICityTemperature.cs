﻿using System.Threading.Tasks;

namespace Walmart.WeatherChallenge.Services
{
    using ViewModel;

    public interface ICityTemperature
    {
        Task<TemperatureViewModel> GetTemperature(string city);
    }
}
