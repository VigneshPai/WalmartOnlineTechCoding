﻿namespace Walmart.WeatherChallenge.ViewModel
{
    /// <summary>
    /// Response from the API with requested details
    /// </summary>
    public class TemperatureViewModel
    {
        public string Name { get; set; }

        public double Temperature { get; set; }

        public long Index { get; set; }
    }
}
