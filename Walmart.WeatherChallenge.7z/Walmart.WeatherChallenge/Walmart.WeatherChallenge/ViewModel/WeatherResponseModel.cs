﻿namespace Walmart.WeatherChallenge.ViewModel
{
    /// <summary>
    /// View Model holding data retrieved from the third party API Call
    /// </summary>
    public class Rootobject
    {
        public Main main { get; set; }
        public int id { get; set; }
        public string name { get; set; }
    }

    public class Main
    {
        public float temp { get; set; }
    }
}
